import { Server } from "./app"
import { pool } from "./pool";

const init = async ()=>{
    const server = new Server();
     server.listen();
    
}

init();