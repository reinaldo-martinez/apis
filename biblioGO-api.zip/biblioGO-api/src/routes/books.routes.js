import Router from 'express'
import { getBooks } from '../controllers/books.controller';
const router = Router()

router.route('/')
    .get(getBooks)

module.exports = router;