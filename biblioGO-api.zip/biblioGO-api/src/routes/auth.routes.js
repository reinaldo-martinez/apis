import {Router} from 'express'
import {check} from 'express-validator'
import { signIn, signUp, validateJWT } from '../controllers/auth.controller';
import { validationRequest } from '../middlewares/validationRequest';
import { revalidateToken } from '../middlewares/revalidateToken';


const router = Router()



router
  .post("/signup", [

    check("name", "El nombre es obligatorio").not().isEmpty(),
    check("email", "El email es obligatorio").isEmail(),
    check("password", "contraseña debe tener mas de 7 caracteres").isLength({ min: 8 }),
    validationRequest

  ], signUp)
  


router
  .post("/signin", [

    check("email", "El email es obligatorio").isEmail(),
    check("password", "contraseña debe tener al menos 8 caracteres").isLength({ min: 8 }),
    validationRequest

  ], signIn)


  router
    .get("/renewtoken", revalidateToken, validateJWT)


module.exports = router