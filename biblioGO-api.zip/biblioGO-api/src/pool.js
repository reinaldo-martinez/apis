const { Pool, Client } = require('pg')
export const pool = new Pool({
  user: 'postgres',
  host: 'localhost',
  database: 'biblioGO',
  password: 'martinez20'
})


