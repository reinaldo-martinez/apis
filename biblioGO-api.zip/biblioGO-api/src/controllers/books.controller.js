import { pool } from "../pool"


export async function getBooks (req, res){

    const books = await pool.query('SELECT * FROM book')
    res.json(books.rows)

}