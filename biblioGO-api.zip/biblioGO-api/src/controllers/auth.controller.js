
import { encryptPassword } from "../helpers/encryptPassword";
import bcrypt from 'bcryptjs'
import { pool } from "../pool";
import { getToken } from "../helpers/getToken";


export async function signUp(req, res) {
  let { name, email, password } = req.body;

  try {
    //verificar que ese email no esté en uso
    const userExists = await pool.query(
      "SELECT email FROM users WHERE email = $1",
      [email]
    );

    if (userExists.rowCount > 0) {
      return res.status(500).json({
        ok: false,
        msg: "this email already exists",
      });
    } else {

      //en caso de que no exista, encriptar contraseña y hacer el insert y generar el token
      password = encryptPassword(password);
      await pool.query(
        "INSERT INTO users (name, email, password, id_rol) VALUES($1, $2, $3, $4)",
        [name, email, password, 1]
      );
      const id_user = await pool.query('SELECT id_user FROM users WHERE email = $1', [email])
      

      const token = await getToken(id_user.rows[0].id_user, email)

      return res.json({
        saved: true,
        msg: "Saved",
        token
      });
    }
  } catch (error) {
    console.log(error);
    res.status(500).json({
      saved : false,
      msg : 'ocurrió un error'
    })
  }
}



export async function signIn(req, res){
    
    const { email, password } = req.body;
    try {
      //verficar si el usuario existe
      const userExists = await pool.query(
        "SELECT id_user, email, password FROM users WHERE email = $1",
        [email]
      );
     
      if (userExists.rowCount == 0) {
        return res.status(400).json({
          ok: false,
          msg: "this email doesn't exists",
        });
      }

      //validate password
      const validPassword = bcrypt.compareSync(password, userExists.rows[0].password)
      if (!validPassword) {
        return res.json({
          login: false,
          msg: "incorrect password",
        });
      }

      //generate token
      const token = await getToken(userExists.rows[0].id_user, email)
      

      res.json({
        login : true,
        user : {
          email,
          password
        },
        token
      })
    } catch (error) {
      console.log(error);
    }
    
}



export async function validateJWT(req, res){
  const id_user = req.id_user
  const email = req.email

  const token = await getToken(id_user, req.email)
  
  res.status(200).json({
    ok : true,
    msg : 'correct',
    token
  })
}