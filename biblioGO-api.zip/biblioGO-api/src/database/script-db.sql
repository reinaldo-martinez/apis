CREATE TABLE "user"(
	id_user serial primary key, 
	"name" varchar(100) not null,
	email varchar(100) not null unique,
	"password" varchar(100) not null,
	id_rol int not null

);

CREATE TABLE book(
	id_book serial primary key,
	title varchar(100) not null,
	id_author int not null,
	id_editorial int not null,
	n_of_pages int not null
);

CREATE TABLE author(
	id_author serial primary key,
	"name" varchar(100) not null,
	date_of_birth date not null
);

CREATE TABLE editorial(
	id_editorial serial primary key,
	"name" varchar(100) not null,
	n_of_books int not null
);

CREATE TABLE rol(
	id_rol serial primary key,
	rol varchar(100)
);

CREATE TABLE book_request(
	id_bookRequest serial primary key,
	id_book int not null,
	id_user int not null,
	dateFrom date not null,
	dateTo date not null
);



